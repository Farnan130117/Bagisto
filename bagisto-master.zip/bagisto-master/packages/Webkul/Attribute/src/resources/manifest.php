 <?php

 return [
    'name'    => 'Webkul Bagisto Attributes',
    'version' => '0.0.1'
 ];
