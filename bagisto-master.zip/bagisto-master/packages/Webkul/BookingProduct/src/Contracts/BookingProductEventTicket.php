<?php

namespace Webkul\BookingProduct\Contracts;

interface BookingProductEventTicket
{
}