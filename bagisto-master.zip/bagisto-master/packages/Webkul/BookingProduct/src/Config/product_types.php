<?php

return [
    'booking' => [
        'key'   => 'booking',
        'name'  => 'Booking',
        'class' => 'Webkul\BookingProduct\Type\Booking',
        'sort'  => 7,
    ]
];